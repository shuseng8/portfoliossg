# Shubham Sen Gupta — portfolio

TanStack Start (React + Vite). The page is `src/routes/index.tsx`. Styles are `src/styles.css`. Photo, icon, and share image are in `public/`.

## Run locally

Node 20+.

```bash
npm install
npm run dev
```

Open http://localhost:8080

## Production build

```bash
npm install
npm run build
```

## Host

This is a server app, not a single HTML file.

- Vercel: import this folder. `vercel.json` is included.
- Any Node host: `npm run build`, then start the server the build prints.

The portfolio itself does not need a database. Auth in this scaffold is off.
